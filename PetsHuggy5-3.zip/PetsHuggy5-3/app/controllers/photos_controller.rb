class PhotosController < ApplicationController
  
end
