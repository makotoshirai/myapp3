class PagesController < ApplicationController
  def index #views/index.html.erbを表示させるというアクション
  end
end
